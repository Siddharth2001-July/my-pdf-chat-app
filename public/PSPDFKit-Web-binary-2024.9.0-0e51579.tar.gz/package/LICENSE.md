## Nutrient Web SDK License Agreement

Please refer to our website to read our evaluation license terms and conditions for Nutrient Web SDK:

https://www.nutrient.io/legal/Nutrient_SDK_User_Evaluation_Subscription_Agreement
